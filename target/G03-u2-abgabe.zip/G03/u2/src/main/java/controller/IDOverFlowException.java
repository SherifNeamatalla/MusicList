package controller;

public class IDOverFlowException extends Exception {

    public IDOverFlowException(){

    }
    public IDOverFlowException ( String message ){
        super(message);

    }
}
